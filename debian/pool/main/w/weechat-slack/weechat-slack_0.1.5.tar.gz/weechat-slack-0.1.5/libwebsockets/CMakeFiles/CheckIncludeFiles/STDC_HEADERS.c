/* */
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <float.h>


int main(void){return 0;}

